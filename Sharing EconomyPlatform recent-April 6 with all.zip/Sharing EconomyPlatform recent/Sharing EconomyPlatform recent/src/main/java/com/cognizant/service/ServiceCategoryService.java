package com.cognizant.service;

import java.util.List;
import java.util.Set;

public interface ServiceCategoryService {
	List<String> getServiceCategories(int vid);

	Set<String> getAllServiceCategories();

}

package com.cognizant.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String username;
	private String password;
	
//	@OneToMany(cascade = CascadeType.ALL)
//	@JoinColumn(name = "product_category_id")
//	private Set<ProductCategory> productCategory;
//	@OneToMany(cascade = CascadeType.ALL)
//	@JoinColumn(name = "service_category_id")
//	private Set<ServiceCategory> serviceCategory;
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "admin")
	//@JoinColumn(name = "product_category_id")
   private Set<ProductCategory> productCategory;
	public Set<ProductCategory> getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(Set<ProductCategory> productCategory) {
		this.productCategory = productCategory;
	}

	@OneToMany(cascade = CascadeType.ALL)
	//@JoinColumn(name = "service_category_id")
      private Set<ServiceCategory> serviceCategory;
	
	
	public Set<ServiceCategory> getServiceCategory() {
		return serviceCategory;
	}

	public void setServiceCategory(Set<ServiceCategory> serviceCategory) {
		this.serviceCategory = serviceCategory;
	}
	
	public Admin() {
		// TODO Auto-generated constructor stub
	}

/**
 * @param id
 * @param username
 * @param password
 */
public Admin(int id, String username, String password) {
	super();
	this.id = id;
	this.username = username;
	this.password = password;
}

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

	
}

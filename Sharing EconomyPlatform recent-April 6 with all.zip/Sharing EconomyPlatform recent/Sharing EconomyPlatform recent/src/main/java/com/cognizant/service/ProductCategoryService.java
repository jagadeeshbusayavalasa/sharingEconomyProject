package com.cognizant.service;

import java.util.List;
import java.util.Set;

public interface ProductCategoryService {
    List<String> getProductCategories(int vid);

	
	Set<String> getAllProductCategories();
}

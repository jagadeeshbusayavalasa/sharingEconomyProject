package com.cognizant.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.stereotype.Service;

import com.cognizant.dao.ServiceCategoryDao;
import com.cognizant.model.ServiceCategory;
@Service
public class ServiceCategoryServiceImpl implements ServiceCategoryService{
	private ServiceCategoryDao serviceCategoryDao;
		public ServiceCategoryServiceImpl(ServiceCategoryDao serviceCategoryDao) {
		super();
		this.serviceCategoryDao = serviceCategoryDao;
	}


	@Override
	public List<String> getServiceCategories(int vid) {
		List<String> categoryName=new ArrayList<>();
		List<ServiceCategory> categories=serviceCategoryDao.findCategories(vid);
		for(ServiceCategory category:categories) {
			categoryName.add(category.getServiceCategoryName());
		}
		
		return categoryName;
	}


	@Override
	public Set<String> getAllServiceCategories() {
		Set<String> categoryNames=new TreeSet<>();
        List<ServiceCategory> categories=serviceCategoryDao.findAll();
        for(ServiceCategory category:categories){
            //System.out.println(category.getServiceCategoryName()+"\t"+category.getServiceCategoryId());
            categoryNames.add(category.getServiceCategoryName());
        }
        return categoryNames;
	}
	

}

package com.cognizant.controller;

import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cognizant.dao.AdminDao;

import com.cognizant.model.Admin;
import com.cognizant.service.AdminService;
import com.cognizant.service.ProductCategoryService;
import com.cognizant.service.ServiceCategoryService;

@Controller
public class AdminController {
	@Autowired
	private AdminDao adminDaoImpl;
	@Autowired
	private AdminService adminServiceImpl;
	@Autowired
	private ProductCategoryService productCategoryService;
	@Autowired
	private ServiceCategoryService serviceCategoryService;
	@GetMapping("/adminLogin")
	public String customerLogin() {
		
		return "adminLogin";
	}
	@PostMapping("/adminAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model) {
	    Admin admin= adminDaoImpl.findByUsernameAndPassword(username, password);
		
	     if (!(ObjectUtils.isEmpty(admin))) {
	    	session.setAttribute("username", username);
	    	System.out.println(session.getAttribute("username"));
	    	return "admin";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "adminLogin";
	     }		
	}
	
	@GetMapping("/adminlogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
	/*@GetMapping("/viewAddProductCategory")
	public String viewAddProductCategory(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_ADDPRODUCTCATEGORY");
		return "vendorDetails";

	}*/

	@GetMapping("/adminproductcategoryform")
	public String productCategoryForm(HttpServletRequest request)
	{
		request.setAttribute("mode", "MODE_ADDPRODUCTCATEGORYFORM");
		return "admin";
	}
	@GetMapping("/adminservicecategoryform")
	public String serviceCategoryForm(HttpServletRequest request)
	{
		request.setAttribute("mode", "MODE_ADDSERVICECATEGORYFORM");
		return "admin";
	}
	@GetMapping("/productcategories")
	@ResponseBody  public Set<String> getProductCategories(){
		//String vendorUserId=(String)session.getAttribute("username");
		//Vendor vendor=vendorDao.findByVendorUserId(vendorUserId);
		Set<String> categories=productCategoryService.getAllProductCategories();
		for(String category:categories)
		{
			System.out.println(category);
		}
		return  categories;
	}
	@GetMapping("/servicecategories")
	@ResponseBody  public Set<String> getServiceCategories(){
		//String vendorUserId=(String)session.getAttribute("username");
		//Vendor vendor=vendorDao.findByVendorUserId(vendorUserId);
		Set<String> categories=serviceCategoryService.getAllServiceCategories();
		for(String category:categories)
		{
			System.out.println(category);
		}
		return  categories;
	}
   @PostMapping("/addProductCategory")
	   public String addProductCategory(@RequestParam("categoryName") String categoryName,HttpSession session,Model model) {
		System.out.println(categoryName);   
		String username=(String) session.getAttribute("username");
		adminServiceImpl.addCategory(username, categoryName);
		model.addAttribute("pmsg", "Category Added Successfully!!");
	   return "admin";
	   }
   @PostMapping("/addservicecategory")
   public String addServiceCategory(@RequestParam("categoryName") String categoryName,Model model,HttpSession session,HttpServletRequest request) {
	System.out.println(categoryName);   
	String username=(String) session.getAttribute("username");
	adminServiceImpl.addServiceCategory(username, categoryName);
	model.addAttribute("pmsg", "Category Added Successfully!!");
   return "admin";
   }
   
}

package com.cognizant.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Service {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int serviceId;
	private String serviceName;
	private float price;
	private String status;
	private String timeings;
	private String contactNumber;
	private int zip;
	
	@ManyToOne(cascade = {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
	@JoinColumn(name = "vendor_id")
	private Vendor vendor;
	
	@ManyToOne(cascade = {CascadeType.DETACH,CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH})
	@JoinColumn(name = "service_category_id")
	private ServiceCategory serviceCategory;
	
	public Service() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param serviceId
	 * @param serviceName
	 * @param price
	 * @param status
	 * @param timeings
	 * @param contactNumber
	 * @param zip
	 * @param vendor
	 * @param serviceCategory
	 */
	public Service(int serviceId, String serviceName, float price, String status, String timeings, String contactNumber,
			int zip, Vendor vendor, ServiceCategory serviceCategory) {
		super();
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.price = price;
		this.status = status;
		this.timeings = timeings;
		this.contactNumber = contactNumber;
		this.zip = zip;
		this.vendor = vendor;
		this.serviceCategory = serviceCategory;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTimeings() {
		return timeings;
	}

	public void setTimeings(String timeings) {
		this.timeings = timeings;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	public ServiceCategory getServiceCategory() {
		return serviceCategory;
	}

	public void setServiceCategory(ServiceCategory serviceCategory) {
		this.serviceCategory = serviceCategory;
	}


}

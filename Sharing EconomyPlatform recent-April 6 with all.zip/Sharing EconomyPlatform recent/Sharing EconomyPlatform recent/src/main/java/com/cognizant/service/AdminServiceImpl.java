package com.cognizant.service;

import java.util.LinkedHashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDao;
import com.cognizant.model.Admin;
import com.cognizant.model.ProductCategory;
import com.cognizant.model.ServiceCategory;
@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao adminDao;
	@Override
	public void addCategory(String username, String categoryName) {
		// TODO Auto-generated method stub
		Admin admin=adminDao.findByUsername(username);
		ProductCategory category=new ProductCategory();
		Set<ProductCategory> categories=new LinkedHashSet();
		category.setProductCategoryName(categoryName);
		category.setAdmin(admin);
		categories.add(category);
	   admin.setProductCategory(categories);
	   adminDao.save(admin);
		
	}
	@Override
	public void addServiceCategory(String username, String categoryName) {
		// TODO Auto-generated method stub
		Admin admin=adminDao.findByUsername(username);
		ServiceCategory category=new ServiceCategory();
		Set<ServiceCategory> categories=new LinkedHashSet();
		category.setServiceCategoryName(categoryName);
		category.setAdmin(admin);
		categories.add(category);
	   admin.setServiceCategory(categories);
	   adminDao.save(admin);
		
		
	}
	
	
}

package com.cognizant.service;

import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.model.ProductCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
@Service
public class ProductCategoryServiceImpl implements ProductCategoryService{
    private ProductCategoryDao productCategoryDao;
    public ProductCategoryServiceImpl(ProductCategoryDao productCategoryDao) {
        this.productCategoryDao = productCategoryDao;
    }

    @Override
    public List<String> getProductCategories(int vid) {
        List<String> categoryNames=new ArrayList<>();
        List<ProductCategory> categories=productCategoryDao.findCategories(vid);
        for(ProductCategory category:categories){
            System.out.println(category.getProductCategoryName()+"\t"+category.getProductCategoryId());
            categoryNames.add(category.getProductCategoryName());
        }
        return categoryNames;
    }

    @Override
    public Set<String> getAllProductCategories() {
        Set<String> categoryNames=new TreeSet<>();
        List<ProductCategory> categories=productCategoryDao.findAll();
        for(ProductCategory category:categories){
            System.out.println(category.getProductCategoryName()+"\t"+category.getProductCategoryId());
            categoryNames.add(category.getProductCategoryName());
        }
        return categoryNames;
    }


	
}

package com.cognizant.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.CustomerDao;
import com.cognizant.model.Customer;
import com.cognizant.model.Vendor;
import com.cognizant.service.CustomerService;
@Service
public class CustomerServiceImpl implements CustomerService {
   @Autowired
   CustomerDao dao;
	public boolean validateSecretAns(String customerUserId, String secretQ, String secretAns) {
		
		// TODO Auto-generated method stub
		boolean b=false;
		Customer customer=dao.findByCustomerUserIdAndSecretQAndSecretAns(customerUserId,secretQ,secretAns);
		if(customer!=null)
		{
		System.out.println(customer.getContactNumber());
		b=true;
		}
		
		return b;	
		
	}
	public void resetPassword(String customerUserId, String password) {
		// TODO Auto-generated method stub
		Customer customer=dao.findByCustomerUserId(customerUserId);
		customer.setPassword(password);
		dao.save(customer);
		System.out.println(customer.getPassword());
	}
	public Customer findByCustomerUserId(String customerUserId) {
		// TODO Auto-generated method stub
		return dao.findByCustomerUserId( customerUserId);
		
	}

	
	
}
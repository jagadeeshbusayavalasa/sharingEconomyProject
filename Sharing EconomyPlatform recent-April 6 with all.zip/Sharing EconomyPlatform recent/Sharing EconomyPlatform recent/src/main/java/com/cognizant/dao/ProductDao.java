package com.cognizant.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Product;
import com.cognizant.model.ProductCategory;
@Repository
public interface ProductDao extends JpaRepository<Product, Integer>{
	Product findByProductId(int pid);
	//@Query(value="select * from product where vendor_id=?1",nativeQuery = true)
	List<Product> findByVendorId(int i);
	
	@Query(value = "select * from product where vendor_id=?1",nativeQuery = true)
	Product findByProductIdAndVendorUserId(int productId);
	
	
	@Query(value = "select * from product where product_category_id=?1",nativeQuery = true)
	List<Product> findByProductCategoryId(int productCategoryId);
	
	@Query(value = "select * from product where product_id=?1 and vendor_id=?2",nativeQuery = true)
	Product findByProductIdAndVendorId(int productId, int vendorId);

	Product findByProductNameAndVendorId(String productName, int vendorId);
		

}

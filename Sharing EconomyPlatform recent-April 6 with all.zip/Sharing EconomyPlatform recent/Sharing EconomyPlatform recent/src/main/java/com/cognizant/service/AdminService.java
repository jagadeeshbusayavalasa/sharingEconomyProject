package com.cognizant.service;

import org.springframework.stereotype.Service;

@Service
public interface AdminService {
	public void addCategory(String username,String categoryName);

	public void addServiceCategory(String username, String categoryName);
}

package com.cognizant.service;

public interface VendorService {

	void update(String currentSession, String firstName, String lastName, String gender, String contactNumber,
			String address, String city, String state, String zip, String email);

	boolean validateSecretAns(String vendorUserId, String secretQ, String secretAns);
	public void resetPassword(String vendorUserId, String password);
}

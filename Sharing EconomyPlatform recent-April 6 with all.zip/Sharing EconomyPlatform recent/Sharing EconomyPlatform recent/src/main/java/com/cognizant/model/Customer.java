package com.cognizant.model;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@NotBlank(message = "First Name should not be empty")
	private String firstName;
	@NotBlank(message = "Last Name shold not be empty")
	private String lastName;
	// @NotBlank(message = "Date of birth should not be empty")
	// private Date dob;
	@NotEmpty(message = "Gender should be specitfied")
	private String gender;
	@NotNull(message = "Contact number should not be empty")
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Contact number should be 10 digits")
	private String contactNumber;
	@NotBlank(message = "Address should not be empty")
	private String address;
	@NotBlank(message = "City should not be empty")
	private String city;
	@NotBlank(message = "State should not be empty")
	private String state;
	@NotBlank(message = "Zip code should not be empty")
	private String zip;
	@NotBlank(message = "Email should not be empty")
	private String email;
	@NotBlank(message = "Customer Id code should not be empty")
	private String customerUserId;
	@NotBlank(message = "Password should not be empty")
	private String password;
	private String secretQ;
	@NotBlank(message = "Secret answer should not be empty")
	private String secretAns;

	@OneToOne(cascade = CascadeType.ALL,mappedBy = "customer")
	private ProductCart productCart;
	

	public Customer() {
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param gender
	 * @param contactNumber
	 * @param address
	 * @param city
	 * @param state
	 * @param zip
	 * @param email
	 * @param customerUserId
	 * @param password
	 * @param secretQ
	 * @param secretAns
	 * @param productCart
	 */
	public Customer(Integer id, @NotBlank(message = "First Name should not be empty") String firstName,
			@NotBlank(message = "Last Name shold not be empty") String lastName,
			@NotEmpty(message = "Gender should be specitfied") String gender,
			@NotNull(message = "Contact number should not be empty") @Pattern(regexp = "(^$|[0-9]{10})", message = "Contact number should be 10 digits") String contactNumber,
			@NotBlank(message = "Address should not be empty") String address,
			@NotBlank(message = "City should not be empty") String city,
			@NotBlank(message = "State should not be empty") String state,
			@NotBlank(message = "Zip code should not be empty") String zip,
			@NotBlank(message = "Email should not be empty") String email,
			@NotBlank(message = "Customer Id code should not be empty") String customerUserId,
			@NotBlank(message = "Password should not be empty") String password, String secretQ,
			@NotBlank(message = "Secret answer should not be empty") String secretAns, ProductCart productCart) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.email = email;
		this.customerUserId = customerUserId;
		this.password = password;
		this.secretQ = secretQ;
		this.secretAns = secretAns;
		this.productCart = productCart;
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getZip() {
		return zip;
	}


	public void setZip(String zip) {
		this.zip = zip;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getCustomerUserId() {
		return customerUserId;
	}


	public void setCustomerUserId(String customerUserId) {
		this.customerUserId = customerUserId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getSecretQ() {
		return secretQ;
	}


	public void setSecretQ(String secretQ) {
		this.secretQ = secretQ;
	}


	public String getSecretAns() {
		return secretAns;
	}


	public void setSecretAns(String secretAns) {
		this.secretAns = secretAns;
	}


	public ProductCart getProductCart() {
		return productCart;
	}


	public void setProductCart(ProductCart productCart) {
		this.productCart = productCart;
	}



	

}

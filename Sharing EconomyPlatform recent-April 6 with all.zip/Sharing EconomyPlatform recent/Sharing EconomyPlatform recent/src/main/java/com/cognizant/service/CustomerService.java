package com.cognizant.service;

public interface CustomerService {
	public boolean validateSecretAns(String vendorUserId, String secretQ, String secretAns);
}

package com.cognizant.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Customer;

@Repository
public interface CustomerDao extends JpaRepository<Customer, Integer> {
	
	
	
	Customer findByCustomerUserIdAndPassword(String username, String password);

	Customer findByCustomerUserIdAndSecretQAndSecretAns(String customerUserId, String secretQ, String secretAns);

	Customer findByCustomerUserId(String customerUserId);
}

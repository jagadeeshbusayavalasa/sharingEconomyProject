package com.cognizant.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.model.Vendor;

public interface VendorDao extends JpaRepository<Vendor,Integer> {

	Vendor findByEmailAndPassword(String username, String password);

}

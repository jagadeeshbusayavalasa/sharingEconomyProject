package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dao.impl.VendorDaoImpl;
import com.cognizant.model.Customer;
import com.cognizant.model.Vendor;
import com.cognizant.service.impl.VendorServiceImpl;
@Controller
public class VendorController {
	@Autowired
	private VendorDaoImpl vendorDaoImpl;	
	@Autowired
	private VendorServiceImpl vendorServiceImpl;
	
	@GetMapping("/vendor")
	public String viewVendorRegister(Model model) {
		Vendor vendor=new Vendor();
		model.addAttribute("vendor",vendor);
		return "vendorRegister";
	}
	@PostMapping("/vendorRegister")
	public String addVendor(@Valid @ModelAttribute("vendor") Vendor vendor,BindingResult result,ModelMap map) {
		if(result.hasErrors()) {
			return "vendorRegister";
		}
		
		vendorDaoImpl.save(vendor);
		return "vendorRegisterSuccess";		
	}
	
    @GetMapping("/vendorLogin")
	public String vendorLogin() {
		
		return "vendorLogin";
	}
	@PostMapping("/vendorAuthentication")
	public String loginAuthentication(@RequestParam("vendorId") String vendorId,
			@RequestParam("password") String password,HttpSession session,Model model) {
	     Vendor vendor=vendorDaoImpl.findByVendorId(vendorId);
	     if (!(ObjectUtils.isEmpty(vendor))) {
	    	session.setAttribute("vendorId", vendorId);
	    	System.out.println(session.getAttribute("vendorId"));
	    	return "vendor";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "vendorLogin";
	     }
		
	}
	@GetMapping("/update")
	public String vendorUpdate(Model model,HttpSession session) {
	   
	  Vendor vendor =vendorDaoImpl.findByVendorId((String)session.getAttribute("vendorId"));
		model.addAttribute("vendor",vendor);
		return "update";
	
	}
	@PostMapping("/updateauthentication")

	public  String vendorUpdateAuthentication( @ModelAttribute("vendor") Vendor vendor,Model model,HttpSession session,
			@RequestParam("firstName") String firstName,@RequestParam("lastName") String lastName,@RequestParam("gender") String gender,
			@RequestParam("city") String city,@RequestParam("state") String state,@RequestParam("zip") String zip,
			@RequestParam("address") String address,@RequestParam("contactNumber") String contactNumber,@RequestParam("email") String email)
		 {
		 
			String currentSession=(String) session.getAttribute("vendorId");
			vendorServiceImpl.update(currentSession, firstName, lastName, gender, contactNumber, address, city, state, zip, email);
		   		    model.addAttribute("msg", "Updated Successfully");
			 return "vendor";
		
		
	}
	
	@GetMapping("/vendorlogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("vendorId"));
		session.removeAttribute("vendorId");
		System.out.println(session.getAttribute("vendorId"));
		return "redirect:/";
	}

	@ModelAttribute("secretQ")
	public List<String> populateQ(){
		List<String> secretQ=new ArrayList<>();
		secretQ.add("What is your childhood name");
		secretQ.add("What is your pet name");
		secretQ.add("Who is your childhood friend");
		return secretQ;
		
		
		
	}
	

}

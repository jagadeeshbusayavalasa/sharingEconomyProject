package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dao.impl.CustomerDaoImpl;
import com.cognizant.model.Customer;

@Controller
public class CustomerController {
	@Autowired
	private CustomerDaoImpl customerDaoImpl;	
	
	@GetMapping("/customer")
	public String viewCustomerRegister(Model model) {
		Customer customer=new Customer();
		model.addAttribute("customer",customer);
		return "customerRegister";
	}
	@PostMapping("/customerRegister")
	public String addVendor(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,ModelMap map) {
		if(result.hasErrors()) {
			return "customerRegister";
		}
		
		customerDaoImpl.save(customer);
		
		return "customerRegisterSuccess";		
	}
	
	@GetMapping("/customerLogin")
	public String customerLogin() {
		
		return "customerLogin";
	}
	@PostMapping("/customerAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model) {
	     Customer correct=customerDaoImpl.findByUsernameAndPassword(username,password);
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	System.out.println(session.getAttribute("username"));
	    	return "customer";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "customerLogin";
	     }
		
	}
	@GetMapping("/customerLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
	@ModelAttribute("secretQ")
	public List<String> populateQ(){
		List<String> secretQ=new ArrayList<>();
		secretQ.add("What is your childhood name");
		secretQ.add("What is your pet name");
		secretQ.add("Who is your childhood friend");
		return secretQ;
	}


}

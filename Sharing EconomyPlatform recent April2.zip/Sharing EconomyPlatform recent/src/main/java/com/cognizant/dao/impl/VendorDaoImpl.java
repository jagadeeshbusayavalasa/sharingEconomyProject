package com.cognizant.dao.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.dao.VendorDao;
import com.cognizant.model.Customer;
import com.cognizant.model.Vendor;

@Service
@Transactional
public class VendorDaoImpl {
	@Autowired
	private VendorDao vendorDao;

		
	public void save(Vendor vendor) {
		vendorDao.save(vendor);		
	}
	public Vendor findByVendorIdAndPassword(String vendorId, String password) {
		// TODO Auto-generated method stub
		return vendorDao.findByvendorIdAndPassword(vendorId, password);
	}
	public Vendor findByVendorId(String vendorId) {
		// TODO Auto-generated method stub
		return vendorDao.findByvendorId(vendorId);
	}


}

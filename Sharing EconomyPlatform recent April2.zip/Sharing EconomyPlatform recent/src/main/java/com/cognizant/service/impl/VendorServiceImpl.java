package com.cognizant.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.dao.impl.VendorDaoImpl;
import com.cognizant.model.Vendor;
import com.cognizant.service.VendorService;
@Service
@Transactional
public class VendorServiceImpl implements VendorService {


	private VendorDaoImpl vendorDaoImpl;	
public VendorServiceImpl(VendorDaoImpl vendorDaoImpl) {
		super();
		this.vendorDaoImpl = vendorDaoImpl;
	}
@Override
	public void update(String currentSession, String firstName, String lastName, String gender, String contactNumber,
			String address, String city, String state, String zip, String email) {
		// TODO Auto-generated method stub
		Vendor vendor=vendorDaoImpl.findByVendorId(currentSession);
		vendor.setFirstName(firstName);
		vendor.setLastName(lastName);
		vendor.setGender(gender);
		vendor.setContactNumber(contactNumber);
		vendor.setCity(city);
		vendor.setAddress(address);
		vendor.setState(state);
		vendor.setZip(zip);
		vendor.setEmail(email);
		vendorDaoImpl.save(vendor);
		
		

	}

}

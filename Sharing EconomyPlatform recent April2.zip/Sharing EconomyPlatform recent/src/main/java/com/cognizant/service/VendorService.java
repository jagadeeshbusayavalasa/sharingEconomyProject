package com.cognizant.service;

public interface VendorService {
	public  void update(String currentSession, String firstName,String lastName,String gender,String contactNumber,String address,String city,
			String state, String zip, String email) ;
	
}
